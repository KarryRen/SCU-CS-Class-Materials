#include "treenode.h"
#include "scanner.h"
#include "util.h"
#include "syntax.h" 
int lineno=0;
FILE* source;
FILE* listing;
FILE* syntax_tree_file;
FILE* code;

int EchoSource=true;
int TraceScan=true;


int main()
{
    source=fopen("test.txt","r");   //������ļ�
    TreeNode* syntaxTree;
    syntaxTree=parse();   //�����﷨����
    listing=stdout;
    fprintf(listing,"\nSyntax tree:\n");
    printTree(syntaxTree);         //��ӡ�﷨��
    fclose(source);
    return 0;
}
