
int add(int a, int b) {
    return a + b;
}


int factorial(int n) {
    if (n <= 1) {
        return 1;
    } else {
        return n * factorial(n - 1);
    }
}

void main() {
    int x;
    int y;
    int result;
    
    x = 10;
    y = 5;
    
    
    result = add(x, y);
    print_result(result);
    
}



