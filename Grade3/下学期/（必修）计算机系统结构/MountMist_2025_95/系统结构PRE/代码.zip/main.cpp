#include <iostream>
#include <vector>
#include <chrono>
#include <cstdlib>
#include <ctime>
#include <algorithm>   // 用于 min 函数
#include <thread>      // 用于多线程
#include <fstream>     // 新增头文件，用于文件操作

using namespace std;

using Matrix = vector<vector<int> >;

/**
 * @brief 使用普通三重循环实现矩阵乘法
 * @param A 矩阵 A
 * @param B 矩阵 B
 * @return 返回矩阵乘积 C = A * B
 */
Matrix naiveMultiply(const Matrix &A, const Matrix &B) {
    const int n = A.size();
    const int m = A[0].size(); // A 的列数，同时也是 B 的行数
    const int p = B[0].size(); // B 的列数
    Matrix C(n, vector<int>(p, 0));
    for (int i = 0; i < n; i++)
        for (int j = 0; j < p; j++)
            for (int k = 0; k < m; k++)
                C[i][j] += A[i][k] * B[k][j];
    return C;
}

/**
 * @brief 返回大于等于 n 的最小 2 的幂次
 * @param n 输入整数
 * @return 返回大于等于 n 的最小 2 的幂次
 */
int nextPowerOfTwo(int n) {
    int p = 1;
    while (p < n) {
        p *= 2;
    }
    return p;
}

/**
 * @brief 将矩阵 A 填充为 newSize×newSize 的矩阵，不足部分填 0
 * @param A 原始矩阵
 * @param newSize 填充后的矩阵大小
 * @return 返回填充后的矩阵
 */
Matrix padMatrix(const Matrix &A, int newSize) {
    int n = A.size();
    Matrix padded(newSize, vector<int>(newSize, 0));
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            padded[i][j] = A[i][j];
    return padded;
}

/**
 * @brief 将填充后的矩阵恢复为原来的 n×n 大小
 * @param A 填充后的矩阵
 * @param originalSize 原始矩阵大小
 * @return 返回恢复后的矩阵
 */
Matrix unpadMatrix(const Matrix &A, int originalSize) {
    Matrix result(originalSize, vector<int>(originalSize, 0));
    for (int i = 0; i < originalSize; i++)
        for (int j = 0; j < originalSize; j++)
            result[i][j] = A[i][j];
    return result;
}

constexpr int STRASSEN_THRESHOLD = 64; // 小于该规模时使用普通乘法


/**
 * @brief 使用Strassen算法递归地计算两个矩阵的乘积。
 *
 * Strassen算法是一种分治算法，通过将矩阵分块并减少乘法运算的次数，
 * 提高了大规模矩阵乘法的效率。该算法的主要思想是将两个矩阵分成4个子矩阵，
 * 然后通过7次递归计算和若干次矩阵加减法来合成结果矩阵。
 *
 * 算法步骤：
 * 1. 基础情况：当矩阵规模小于等于阈值时，直接使用普通矩阵乘法。
 * 2. 分块：将输入矩阵A和B分成4个大小为newSize×newSize的子矩阵。
 * 3. 计算7个中间矩阵M1 ~ M7：
 *    - M1 = (A11 + A22) * (B11 + B22)
 *    - M2 = (A21 + A22) * B11
 *    - M3 = A11 * (B12 - B22)
 *    - M4 = A22 * (B21 - B11)
 *    - M5 = (A11 + A12) * B22
 *    - M6 = (A21 - A11) * (B11 + B12)
 *    - M7 = (A12 - A22) * (B21 + B22)
 * 4. 合成结果矩阵C：
 *    - C11 = M1 + M4 - M5 + M7
 *    - C12 = M3 + M5
 *    - C21 = M2 + M4
 *    - C22 = M1 - M2 + M3 + M6
 * 5. 将子矩阵C11, C12, C21, C22合并成最终结果矩阵C。
 *
 * @param A 输入矩阵A
 * @param B 输入矩阵B
 * @return Matrix 返回矩阵A和矩阵B的乘积
 */
Matrix strassenRecursive(const Matrix &A, const Matrix &B) {
    int n = A.size();

    // 基础情况：当矩阵规模小于等于阈值时，使用普通矩阵乘法
    if (n <= STRASSEN_THRESHOLD)
        return naiveMultiply(A, B);

    int newSize = n / 2; // 将矩阵分成 4 个 newSize×newSize 的子矩阵

    // 分块：将 A 和 B 分成 4 个 newSize×newSize 的子矩阵
    Matrix A11(newSize, vector<int>(newSize, 0));
    Matrix A12(newSize, vector<int>(newSize, 0));
    Matrix A21(newSize, vector<int>(newSize, 0));
    Matrix A22(newSize, vector<int>(newSize, 0));

    Matrix B11(newSize, vector<int>(newSize, 0));
    Matrix B12(newSize, vector<int>(newSize, 0));
    Matrix B21(newSize, vector<int>(newSize, 0));
    Matrix B22(newSize, vector<int>(newSize, 0));

    for (int i = 0; i < newSize; i++) {
        for (int j = 0; j < newSize; j++) {
            A11[i][j] = A[i][j];
            A12[i][j] = A[i][j + newSize];
            A21[i][j] = A[i + newSize][j];
            A22[i][j] = A[i + newSize][j + newSize];

            B11[i][j] = B[i][j];
            B12[i][j] = B[i][j + newSize];
            B21[i][j] = B[i + newSize][j];
            B22[i][j] = B[i + newSize][j + newSize];
        }
    }

    // 以下计算 M1 ~ M7
    Matrix A11_A22(newSize, vector<int>(newSize, 0));
    Matrix B11_B22(newSize, vector<int>(newSize, 0));
    for (int i = 0; i < newSize; i++)
        for (int j = 0; j < newSize; j++) {
            A11_A22[i][j] = A11[i][j] + A22[i][j];
            B11_B22[i][j] = B11[i][j] + B22[i][j];
        }
    Matrix M1 = strassenRecursive(A11_A22, B11_B22);

    Matrix A21_A22(newSize, vector<int>(newSize, 0));
    for (int i = 0; i < newSize; i++)
        for (int j = 0; j < newSize; j++)
            A21_A22[i][j] = A21[i][j] + A22[i][j];
    Matrix M2 = strassenRecursive(A21_A22, B11);

    Matrix B12_B22(newSize, vector<int>(newSize, 0));
    for (int i = 0; i < newSize; i++)
        for (int j = 0; j < newSize; j++)
            B12_B22[i][j] = B12[i][j] - B22[i][j];
    Matrix M3 = strassenRecursive(A11, B12_B22);

    Matrix B21_B11(newSize, vector<int>(newSize, 0));
    for (int i = 0; i < newSize; i++)
        for (int j = 0; j < newSize; j++)
            B21_B11[i][j] = B21[i][j] - B11[i][j];
    Matrix M4 = strassenRecursive(A22, B21_B11);

    Matrix A11_A12(newSize, vector<int>(newSize, 0));
    for (int i = 0; i < newSize; i++)
        for (int j = 0; j < newSize; j++)
            A11_A12[i][j] = A11[i][j] + A12[i][j];
    Matrix M5 = strassenRecursive(A11_A12, B22);

    Matrix A21_A11(newSize, vector<int>(newSize, 0));
    Matrix B11_B12(newSize, vector<int>(newSize, 0));
    for (int i = 0; i < newSize; i++) {
        for (int j = 0; j < newSize; j++) {
            A21_A11[i][j] = A21[i][j] - A11[i][j];
            B11_B12[i][j] = B11[i][j] + B12[i][j];
        }
    }
    Matrix M6 = strassenRecursive(A21_A11, B11_B12);

    Matrix A12_A22(newSize, vector<int>(newSize, 0));
    Matrix B21_B22(newSize, vector<int>(newSize, 0));
    for (int i = 0; i < newSize; i++) {
        for (int j = 0; j < newSize; j++) {
            A12_A22[i][j] = A12[i][j] - A22[i][j];
            B21_B22[i][j] = B21[i][j] + B22[i][j];
        }
    }
    Matrix M7 = strassenRecursive(A12_A22, B21_B22);

    Matrix C11(newSize, vector<int>(newSize, 0));
    Matrix C12(newSize, vector<int>(newSize, 0));
    Matrix C21(newSize, vector<int>(newSize, 0));
    Matrix C22(newSize, vector<int>(newSize, 0));

    for (int i = 0; i < newSize; i++) {
        for (int j = 0; j < newSize; j++) {
            C11[i][j] = M1[i][j] + M4[i][j] - M5[i][j] + M7[i][j];
            C12[i][j] = M3[i][j] + M5[i][j];
            C21[i][j] = M2[i][j] + M4[i][j];
            C22[i][j] = M1[i][j] - M2[i][j] + M3[i][j] + M6[i][j];
        }
    }

    Matrix C(n, vector<int>(n, 0));
    for (int i = 0; i < newSize; i++) {
        for (int j = 0; j < newSize; j++) {
            C[i][j] = C11[i][j];
            C[i][j + newSize] = C12[i][j];
            C[i + newSize][j] = C21[i][j];
            C[i + newSize][j + newSize] = C22[i][j];
        }
    }
    return C;
}

/**
 * @brief 使用 Strassen 算法进行矩阵乘法
 * @param A 矩阵 A
 * @param B 矩阵 B
 * @return 返回矩阵乘积 C = A * B
 */
Matrix strassenMultiply(const Matrix &A, const Matrix &B) {
    int n = A.size(); // 获取矩阵 A 的大小（假设 A 为 n×n 矩阵）

    // 计算大于等于 n 的最小 2 的幂次，确保矩阵大小为 2 的幂次
    int m = nextPowerOfTwo(n);

    // 将矩阵 A 和 B 填充为 m×m 的矩阵，不足部分填充为 0
    Matrix A_padded = padMatrix(A, m);
    Matrix B_padded = padMatrix(B, m);

    // 使用 Strassen 算法递归计算填充后的矩阵乘积
    Matrix C_padded = strassenRecursive(A_padded, B_padded);

    // 将结果矩阵恢复为原始大小 n×n
    Matrix C = unpadMatrix(C_padded, n);

    return C; // 返回最终的矩阵乘积
}

/**
 * @brief 使用循环分块优化实现矩阵乘法
 * @param A 矩阵 A
 * @param B 矩阵 B
 * @param blockSize 块大小
 * @return 返回矩阵乘积 C = A * B
 * @note 利用块数据能够完全或大部分装入 CPU 缓存的特性，降低因频繁访问主内存而产生的延迟。
 */
Matrix optimizedMultiply(const Matrix &A, const Matrix &B, int blockSize = 32) {
    int n = A.size();
    Matrix C(n, vector<int>(n, 0)); // 初始化结果矩阵 C，假设 A 和 B 均为 n×n 矩阵

    // 分块循环：将矩阵分成 blockSize×blockSize 的小块进行计算
    for (int i0 = 0; i0 < n; i0 += blockSize) {
        // 遍历 A 的行块
        for (int k0 = 0; k0 < n; k0 += blockSize) {
            // 遍历 A 的列块（同时也是 B 的行块）
            for (int j0 = 0; j0 < n; j0 += blockSize) {
                // 遍历 B 的列块
                // 确定当前块的边界，避免越界
                int iMax = min(i0 + blockSize, n);
                int kMax = min(k0 + blockSize, n);
                int jMax = min(j0 + blockSize, n);

                // 遍历当前块中的元素
                for (int i = i0; i < iMax; i++) {
                    // 遍历当前行块的行
                    for (int k = k0; k < kMax; k++) {
                        // 遍历当前列块的列
                        int a_ik = A[i][k]; // 提取 A 的当前元素，减少重复访问
                        for (int j = j0; j < jMax; j++) {
                            // 遍历 B 的列块的列
                            C[i][j] += a_ik * B[k][j]; // 累加计算结果到 C 的对应位置
                        }
                    }
                }
            }
        }
    }
    return C; // 返回结果矩阵 C
}

/**
 * @brief 使用多线程并行实现矩阵乘法
 * @param A 矩阵 A
 * @param B 矩阵 B
 * @return 返回矩阵乘积 C = A * B
 * @note 按矩阵行数均分工作，每个线程负责计算部分行的结果。
 */
Matrix parallelMultiply(const Matrix &A, const Matrix &B) {
    int n = A.size(); // 获取矩阵 A 的行数
    int m = A[0].size(); // 获取矩阵 A 的列数（同时也是矩阵 B 的行数）
    int p = B[0].size(); // 获取矩阵 B 的列数
    Matrix C(n, vector<int>(p, 0)); // 初始化结果矩阵 C，大小为 n×p，初始值为 0

    // 获取硬件支持的线程数，若无法获取则默认使用 4 个线程
    unsigned int numThreads = thread::hardware_concurrency();
    if (numThreads == 0)
        numThreads = 4;

    vector<thread> threads; // 用于存储线程对象
    int rowsPerThread = n / numThreads; // 每个线程处理的行数
    int extraRows = n % numThreads; // 处理剩余行的线程数
    int startRow = 0; // 当前线程的起始行索引

    // 创建线程，每个线程负责计算部分行的结果
    for (unsigned int t = 0; t < numThreads; t++) {
        int endRow = startRow + rowsPerThread + (t < extraRows ? 1 : 0); // 确定当前线程的结束行索引
        threads.emplace_back([&, startRow, endRow]() {
            // 使用 lambda 表达式创建线程
            for (int i = startRow; i < endRow; i++) {
                // 遍历当前线程负责的行
                for (int j = 0; j < p; j++) {
                    // 遍历结果矩阵的列
                    int sum = 0; // 用于存储当前元素的累加结果
                    for (int k = 0; k < m; k++) {
                        // 遍历矩阵 A 的列和矩阵 B 的行
                        sum += A[i][k] * B[k][j]; // 计算矩阵乘法的单个元素
                    }
                    C[i][j] = sum; // 将计算结果存入结果矩阵
                }
            }
        });
        startRow = endRow; // 更新起始行索引，供下一个线程使用
    }

    // 等待所有线程完成计算
    for (auto &th: threads) {
        th.join();
    }

    return C; // 返回结果矩阵
}

/**
 * @brief 随机生成 n×n 的矩阵（元素范围 0~9）
 * @param n 矩阵大小
 * @return 返回随机生成的矩阵
 */
Matrix generateRandomMatrix(int n) {
    Matrix A(n, vector<int>(n, 0));
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            A[i][j] = rand() % 10;
    return A;
}

/**
 * @brief 比较两个矩阵是否相等
 * @param A 矩阵 A
 * @param B 矩阵 B
 * @return 如果两个矩阵相等返回 true，否则返回 false
 */
bool compareMatrices(const Matrix &A, const Matrix &B) {
    int n = A.size(), m = A[0].size();
    for (int i = 0; i < n; i++)
        for (int j = 0; j < m; j++)
            if (A[i][j] != B[i][j])
                return false;
    return true;
}

int main() {
    system("chcp 65001");
    const int seed = 42;
    srand(static_cast<unsigned int>(seed));

    // 测试矩阵规模
    vector<int> sizes = {100, 500, 1000};

    // 打开 CSV 文件，准备写入结果
    ofstream csvFile("data.csv");
    if (!csvFile.is_open()) {
        cerr << "无法打开 CSV 文件！" << endl;
        return 1;
    }
    // 写入 CSV 文件表头
    csvFile << "size,normal,strassen,block,thread,same" << endl;

    for (int size: sizes) {
        constexpr int iterations = 1;
        cout << "矩阵规模: " << size << " x " << size << endl;
        Matrix A = generateRandomMatrix(size);
        Matrix B = generateRandomMatrix(size);

        double naiveTimeSum = 0.0;
        double strassenTimeSum = 0.0;
        double optimizedTimeSum = 0.0;
        double parallelTimeSum = 0.0;

        Matrix resultNaive, resultStrassen, resultOptimized, resultParallel;

        // 普通三重循环测试（以毫秒为单位）
        for (int i = 0; i < iterations; i++) {
            auto start = chrono::high_resolution_clock::now();
            resultNaive = naiveMultiply(A, B);
            auto end = chrono::high_resolution_clock::now();
            chrono::duration<double, milli> elapsed = end - start;
            naiveTimeSum += elapsed.count();
        }
        cout << "普通三重循环耗时平均: " << naiveTimeSum / iterations << " 毫秒" << endl;

        // Strassen 算法测试
        for (int i = 0; i < iterations; i++) {
            auto start = chrono::high_resolution_clock::now();
            resultStrassen = strassenMultiply(A, B);
            auto end = chrono::high_resolution_clock::now();
            chrono::duration<double, milli> elapsed = end - start;
            strassenTimeSum += elapsed.count();
        }
        cout << "Strassen 算法耗时平均: " << strassenTimeSum / iterations << " 毫秒" << endl;

        // 循环分块优化测试
        for (int i = 0; i < iterations; i++) {
            auto start = chrono::high_resolution_clock::now();
            resultOptimized = optimizedMultiply(A, B);
            auto end = chrono::high_resolution_clock::now();
            chrono::duration<double, milli> elapsed = end - start;
            optimizedTimeSum += elapsed.count();
        }
        cout << "循环分块优化耗时平均: " << optimizedTimeSum / iterations << " 毫秒" << endl;

        // 循环分块优化测试
        for (int i = 0; i < iterations; i++) {
            auto start = chrono::high_resolution_clock::now();
            resultOptimized = optimizedMultiply(A, B, 32);
            auto end = chrono::high_resolution_clock::now();
            chrono::duration<double, milli> elapsed = end - start;
            optimizedTimeSum += elapsed.count();
        }
        cout << "循环分块优化耗时平均: " << optimizedTimeSum / iterations << " 毫秒" << endl;

        // 多线程并行算法测试
        for (int i = 0; i < iterations; i++) {
            auto start = chrono::high_resolution_clock::now();
            resultParallel = parallelMultiply(A, B);
            auto end = chrono::high_resolution_clock::now();
            chrono::duration<double, milli> elapsed = end - start;
            parallelTimeSum += elapsed.count();
        }
        cout << "多线程并行耗时平均: " << parallelTimeSum / iterations << " 毫秒" << endl;

        // 验证所有算法计算结果是否一致
        bool resultsMatch = compareMatrices(resultNaive, resultStrassen) &&
                            compareMatrices(resultNaive, resultOptimized) &&
                            compareMatrices(resultNaive, resultParallel);
        if (resultsMatch)
            cout << "所有算法计算结果一致。" << endl;
        else
            cout << "结果不匹配！" << endl;

        // 将结果写入 CSV 文件
        csvFile << size << ","
                << naiveTimeSum / iterations << ","
                << strassenTimeSum / iterations << ","
                << optimizedTimeSum / iterations << ","
                << parallelTimeSum / iterations << ","
                << resultsMatch << endl;

        cout << "--------------------------------------------" << endl;
    }

    // 关闭 CSV 文件
    csvFile.close();

    return 0;
}
