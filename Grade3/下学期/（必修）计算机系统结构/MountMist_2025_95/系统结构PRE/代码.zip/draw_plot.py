import pandas as pd
import matplotlib.pyplot as plt
import os

# 执行矩阵乘法C++程序
# os.system("main.exe")

# 读取csv数据
data = pd.read_csv("data.csv")

# 设置窗口标题栏
data.plot(
    x="size",
    y=["normal", "strassen", "block", "thread"],
    kind="bar",
    logy=True,
    title="Matrix Multiplication Performance",
)
plt.show()
