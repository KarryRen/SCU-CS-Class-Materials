import pandas as pd
import numpy as np


dict= {}
price_add={
    "花叶类":94.517, #4.0
    "花菜类":62.463, #2.5
    "水生根茎类":53.805, #2.5
    "茄类":62.010, #4
    "辣椒类":53.967, #6
    "食用菌":62.221 #4
}
df=pd.read_excel(io="../../data/dataget/附件1.xlsx")

for index,row in df.iterrows():
    dict[row["单品名称"]]={"num":row["单品编码"],"type":row["分类名称"]}

df=pd.read_excel(io=r"../../data/dataget/附件4.xlsx",sheet_name="Sheet1")
for index,row in df.iterrows():
    dict[row["单品名称"]]["loss"]=row["损耗率"]/100



file_root_path="../dataget"

profit={}
info={}

df=pd.read_excel(io=file_root_path+"/进价预测.xlsx")
columns=df.columns[1:]
for name in columns:
    profit[name]=df[name][1]
    info[name]={"price":0,"cost":df[name][1],"sale":0,"add":0,"loss":0}

df=pd.read_excel(io=file_root_path+"/销量预测.xlsx")
columns=df.columns[1:]
for name in columns:
    profit[name]=df[name][1]*profit[name]
    info[name]["sale"]=df[name][1]

for name in profit.keys():
    profit[name]=profit[name]*(1-dict[name]["loss"])*price_add[dict[name]["type"]]/100
    info[name]["loss"]=dict[name]["loss"]
    info[name]["add"]=price_add[dict[name]["type"]]
    info[name]["price"]=info[name]["cost"]*(1+info[name]["add"]/100)

profit = sorted(profit.items(),  key=lambda d: d[1], reverse=True)

columns=[]
for name in profit:
    columns.append(name[0])

out_index=["预测利润","预测进价","加价率","定价","预测销量","损耗率"]

zero_input=np.zeros((len(columns),6))
out=pd.DataFrame(zero_input,columns=out_index, index=columns)

for name in profit:
    out["预测利润"][name[0]]=name[1]
    out["预测进价"][name[0]]=info[name[0]]["cost"]
    out["加价率"][name[0]] = info[name[0]]["add"]
    out["定价"][name[0]] = info[name[0]]["price"]
    out["预测销量"][name[0]] = info[name[0]]["sale"]
    out["损耗率"][name[0]] = info[name[0]]["loss"]


out_path="../data"
out.to_excel(out_path+"/利润.xlsx",sheet_name = "汇总",index = True,na_rep = 0,inf_rep = 0)