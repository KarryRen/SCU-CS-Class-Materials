import pandas as pd
import json

file_root_path="../dataget/"

df=pd.read_excel(io=file_root_path+"附件2.xlsx")
dict={}

datenow=""
date_str=""

for index, row in df.iterrows():
    if str(row["销售日期"])!=datenow:
        datenow=str(row["销售日期"])
        date_str=datenow.split(' ',1)[0]
        print(date_str)


    if row["单品编码"] in dict:
        if date_str in dict[row["单品编码"]]:
            dict[row["单品编码"]][date_str]["sale"]+=row["销量(千克)"]
            dict[row["单品编码"]][date_str]["total_sale"] += row["销量(千克)"]*row["销售单价(元/千克)"]
            dict[row["单品编码"]][date_str]["price"]=max(dict[row["单品编码"]][date_str]["price"],row["销售单价(元/千克)"])
        else:
            dict[row["单品编码"]][date_str]={
                "sale":row["销量(千克)"],
                "price":row["销售单价(元/千克)"],
                "total_sale":row["销量(千克)"]*row["销售单价(元/千克)"]
            }
    else:
        dict[row["单品编码"]]={}

f=open("../data/price2.json","w")
json.dump(dict,f)
f.close()




df=pd.read_excel(io=file_root_path+"3.xlsx")
for index, row in df.iterrows():
    date_str=str(row["销售日期"]).split(' ',1)[0]
    if row["单品编码"] in dict:
        if date_str in dict[row["单品编码"]]:
            dict[row["单品编码"]][date_str]["cost"]=row["批发价格(元/千克)"]
        else:
            num=row["单品编码"]
            print(f"cost not found in num : {num}, date : {date_str}")
    else:
        num = row["单品编码"]
        print(f"num not found in num : {num}, date : {date_str}")

f=open("../data/price3.json","w")
json.dump(dict,f)
f.close()