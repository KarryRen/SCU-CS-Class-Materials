import json
import pulp
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn import linear_model,preprocessing,datasets
import os

plt.rcParams["font.sans-serif"]=["SimHei"] #设置字体
plt.rcParams["axes.unicode_minus"]=False #该语句解决图像中的“-”负号的乱码问题



x_hat={}
y_hat={}
type_index=[]

interference_threshold={
    "花叶类":3.0, #4.0
    "花菜类":1.5, #2.5
    "水生根茎类":1.5, #2.5
    "茄类":1.5, #4
    "辣椒类":3.0, #6
    "食用菌":1.5 #4
}

dict= {}
df=pd.read_excel(io="../../data/dataget/1.xlsx")


for index,row in df.iterrows():
    dict[row["单品编码"]]={"name":row["单品名称"],"type":row["分类名称"]}
    if row["单品编码"]==102900005117056:
        print("e")
    if row["分类名称"] not in x_hat:
        x_hat[row["分类名称"]]=[]
        y_hat[row["分类名称"]]=[]
        type_index.append(row["分类名称"])

df=pd.read_excel(io=r"../../data/dataget/4.xlsx",sheet_name="Sheet1")
for index,row in df.iterrows():
    dict[int(row["单品编码"])]["loss"]=row["损耗率"]/100


data_root_path=r"../../data/data/"
dir_root_path=r"../data"
data = {}

def dataget():
    global data
    f=open(data_root_path+"price3.json","r")
    data=json.load(f)
    f.close()


def liner_get(product_num):
    global x_hat,y_hat
    for value in (data[product_num]).values():
        if (value["price"] / value["cost"] - 1) > interference_threshold[dict[int(product_num)]["type"]]:
            continue
        if (value["price"] / value["cost"] - 1) < 0:
            continue
        x_hat[dict[int(product_num)]["type"]].append(value["price"]/value["cost"]-1)
        #x_hat[dict[int(product_num)]["type"]].append(value["cost"])
        if "loss" not in dict[int(product_num)]:
            print(f"error in {product_num}")
        #y_hat[dict[int(product_num)]["type"]].append(value["total_sale"]-value["cost"]*value["sale"]/(1-dict[int(product_num)]["loss"]))
        y_hat[dict[int(product_num)]["type"]].append(value["total_sale"] - value["cost"] * value["sale"])
        #y_hat[dict[int(product_num)]["type"]].append(value["sale"])

    if len(x_hat) == 0:
        print(f"error in {product_num}")
        return
    return


def type_show(type):
    print(type)
    plt.scatter(x_hat[type],y_hat[type])
    x_hat_in = np.array(x_hat[type]).reshape(-1, 1)
    y_hat_in = np.array(y_hat[type]).reshape(-1, 1)

    x_in=np.arange(0,max(x_hat[type]),0.01)
    reg = np.polyfit(x_hat[type], y_hat[type], 2)
    z=np.poly1d(reg)
    y_in=z(x_in)

    plt.scatter(x_hat[type], y_hat[type],c="green")
    plot = plt.plot(x_in, y_in, color='black')

    plt.xlabel("加成率")
    plt.ylabel("单日利润")

    plt.title(type)
    plt.show()
    plt.cla()


if __name__ == "__main__":
    dataget()
    for key in data:
        liner_get(key)

    for iter in type_index:
        type_show(iter)


