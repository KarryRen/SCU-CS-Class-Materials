import json
import pulp
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn import linear_model,preprocessing,datasets
import os

RATE=0.01
MAX_NUMS=3

plt.rcParams["font.sans-serif"]=["SimHei"] #设置字体
plt.rcParams["axes.unicode_minus"]=False #该语句解决图像中的“-”负号的乱码问题



x_hat={}
y_hat={}
type_index=[]


dict= {}
df=pd.read_excel(io="../../data/dataget/1.xlsx")
point={}

for index,row in df.iterrows():
    dict[row["单品编码"]]={"name":row["单品名称"],"type":row["分类名称"]}
    if row["单品编码"]==102900005117056:
        print("e")
    if row["分类名称"] not in type_index:
        point[row["分类名称"]]={}
        type_index.append(row["分类名称"])

df=pd.read_excel(io=r"../../data/dataget/4.xlsx",sheet_name="Sheet1")
for index,row in df.iterrows():
    dict[int(row["单品编码"])]["loss"]=row["损耗率"]/100


data_root_path=r"../../data/data/"
dir_root_path=r"../data"
data = {}

np_step=np.arange(0,4,RATE)
for key in type_index:
    for iter in range(int(4/RATE)):
        point[key][iter]=[]

def dataget():
    global data
    f=open(data_root_path+"price3.json","r")
    data=json.load(f)
    f.close()


def liner_get(product_num):
    global x_hat,y_hat
    for value in (data[product_num]).values():
        if (value["price"] / value["cost"] - 1) > interference_threshold[dict[int(product_num)]["type"]]:
            continue
        if (value["price"] / value["cost"] - 1) <= 0:
            continue
        if "loss" not in dict[int(product_num)]:
            print(f"error in {product_num}")

        point[dict[int(product_num)]["type"]][int((value["price"]/value["cost"]-1)/RATE)].append(
            (value["price"]/value["cost"]-1 , value["total_sale"] - value["cost"] * value["sale"]/ (1 - dict[int(product_num)]["loss"]) )
        )

    if len(x_hat) == 0:
        print(f"error in {product_num}")
        return
    return


def type_show(type):
    print(type)
    x_hat=[]
    y_hat=[]

    for iter in range(0,int(4/RATE)):
        point_list = point[type][iter]
        point_list = sorted(point_list, key=lambda x: x[1], reverse=True)
        for j in range(len(point_list)):
            if j>= MAX_NUMS:
                break
            t=point_list[j]
            x_hat.append(t[0])
            y_hat.append(t[1])


    reg = np.polyfit(x_hat, y_hat, 5)


    z=np.poly1d(reg)
    print(z)
    x_in = np.arange(0, max(x_hat), 0.01)
    y_in=z(x_in)

    plt.scatter(x_hat, y_hat,c="green")
    plot = plt.plot(x_in, y_in, color='black')

    plt.xlabel("加成率")
    plt.ylabel("单日利润")

    plt.title(type)
    plt.show()
    plt.cla()


if __name__ == "__main__":
    dataget()
    for key in data:
        liner_get(key)

    for it in type_index:
        type_show(it)


