import json
import pulp
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn import linear_model,preprocessing,datasets
import os

plt.rcParams["font.sans-serif"]=["SimHei"] #设置字体
plt.rcParams["axes.unicode_minus"]=False #该语句解决图像中的“-”负号的乱码问题



x_hat={}
y_hat={}
x_test={}
y_test={}
type_index=[]
dict= {}

total_line_loss={}
total_mult_loss={}


df=pd.read_excel(io="../../data/dataget/附件1.xlsx")
for index,row in df.iterrows():
    dict[row["单品名称"]]={"num":row["单品编码"],"type":row["分类名称"]}
    if row["分类名称"] not in type_index:
        type_index.append(row["分类名称"])





data_root_path=r"../../data/data/"
dir_root_path=r"../销量预测"

df = pd.read_excel(io=r"../../data/dataget/单品日销售额_处理有包.xlsx")
columns=df.columns[1:]



out_index=list(range(1,8))
zero_input=np.zeros((len(out_index),len(columns)))
data_out=pd.DataFrame(zero_input,columns=columns, index=out_index)



print(columns)
print(type_index)

for type in type_index:
    x_hat[type] = []
    y_hat[type] = []
    x_test[type] = []
    y_test[type] = []

for type in columns:
    x_hat[type] = []
    y_hat[type] = []
    x_test[type] = []
    y_test[type] = []

day_iter=2
for index,row in df.iterrows():

    if day_iter >=2 and day_iter<=8:
        for name in columns:
            if(row[name]==0):
                continue
            x_hat[dict[name]["type"]].append(day_iter-2)
            y_hat[dict[name]["type"]].append(row[name])
            x_hat[name].append(day_iter - 2)
            y_hat[name].append(row[name])

    if day_iter >=335 and day_iter<=395:
        for name in columns:
            if(row[name]==0):
                continue
            x_hat[dict[name]["type"]].append(day_iter-335)
            y_hat[dict[name]["type"]].append(row[name])
            x_hat[name].append(day_iter - 335)
            y_hat[name].append(row[name])

    if day_iter >=699 and day_iter<=759:
        for name in columns:
            #if(row[name]==0):
            #    continue
            x_test[dict[name]["type"]].append(day_iter-699)
            y_test[dict[name]["type"]].append(row[name])
            x_test[name].append(day_iter - 699)
            y_test[name].append(row[name])

    if day_iter >=1057 and day_iter<=1086:
        for name in columns:
            if(row[name]==0):
                continue
            x_hat[dict[name]["type"]].append(day_iter-1057)
            y_hat[dict[name]["type"]].append(row[name])
            x_hat[name].append(day_iter - 1057)
            y_hat[name].append(row[name])

    day_iter+=1

def del_zero(x_in,y_in):
    x_out=[]
    y_out=[]
    if len(x_in)==0:
        return x_out,y_out
    for i in range(len(x_in)):
        if y_in[i]!=0:
            x_out.append(x_in[i])
            y_out.append(y_in[i])
    return x_out,y_out


def MSE_loss(y_in,y_predict):
    loss=0.0
    for i in range(len(y_in)):
        loss+=(y_predict[i]-y_in[i])*(y_predict[i]-y_in[i])/2

    loss=loss/len(y_in)
    return loss


def type_show(type_in):
    if type_in not in x_hat:
        return
    x_=x_hat[type_in]
    y_=y_hat[type_in]
    if len(x_)==0:
        print(f"error in typename : {type_in}")
        return

    plt.xlabel("日期")
    plt.ylabel("销量/(kg/包)")
    plt.scatter(x_,y_,c="blue")

    x_no_zero,y_no_zero=del_zero(x_test[type_in],y_test[type_in])
    plt.scatter(x_no_zero,y_no_zero,c="green")


    reg1=np.polyfit(x_, y_, 3)
    x_pre1=np.arange(1,60,0.1)
    z=np.poly1d(reg1)
    y_pre1=z(x_pre1)
    loss1=MSE_loss(y_test[type_in],z(x_test[type_in]))
    total_line_loss[type_in]=loss1
    print(f"{type_in}---loss line : {loss1}")
    plot1 = plt.plot(x_pre1, y_pre1, c='red', linewidth=2)

    y_data=z(list(range(30,37)))
    for i in range(0,7):
        if y_data[i]<=0:
            y_data[i]=0
        data_out[type_in][i+1]=y_data[i]


    x_ = np.array(x_).reshape(-1, 1)
    y_ = np.array(y_).reshape(-1, 1)
    reg2=linear_model.LinearRegression()
    reg2.fit(x_,y_)
    x_pre2=np.arange(1,60).reshape(-1,1)
    y_pre2=reg2.predict(x_pre2)
    loss2=MSE_loss(y_test[type_in],reg2.predict(np.array(x_test[type_in]).reshape(-1, 1)))
    total_mult_loss[type_in] = loss2
    print(f"{type_in}---loss mult : {loss2}")
    plot2=plt.plot(x_pre2,y_pre2,c='blue',linewidth=2)

    plt.title(type_in)
    plt.savefig(dir_root_path+r"/"+type_in+".png")
    #plt.show()
    plt.cla()

if __name__=="__main__":
    print("销量损失：")
    for type in columns:
        type_show(type)
    data_out.to_excel(dir_root_path+r"/销量预测.xlsx")

    zero_input = np.zeros((2, len(columns)))
    loss_out = pd.DataFrame(zero_input, columns=columns, index=["线性损失", "非线性损失"])
    for name in columns:
        if name not in total_line_loss:
            continue
        loss_out[name]["线性损失"] = total_line_loss[name]
        loss_out[name]["非线性损失"] = total_mult_loss[name]

    loss_out.to_excel(dir_root_path + r"/销量损失.xlsx")